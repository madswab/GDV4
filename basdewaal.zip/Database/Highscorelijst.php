<?php
    include "DatabaseInlog.php";


if (isset($_GET['PHPSESSID'])){
    $sid = htmlspecialchars($_GET['PHPSESSID']);
    session_id($sid);   
    session_start(); 
}


if (isset($_POST["Total"]) && isset($_SESSION['Speler'])){
     $query = "SELECT s.Score, s.Date, u.Nickname FROM Score s LEFT JOIN Users u ON (s.Player_id = u.Id) WHERE s.GameName = '".$_POST['Game']."' AND s.Player_id = ".$_SESSION['Speler']."  ORDER BY s.Score DESC"; 
    
    if (!($result = $mysqli->query($query))){
        showerror($mysqli->errno,$mysqli->error);
        echo "oops";
    }else{

        $result = $mysqli->query($query);    

        $length = 0;
        $t = array();
        $result = $mysqli->query($query);    
        while($row = mysqli_fetch_assoc($result)){                       
            $t[] = $row;
            $length++;
        }
        echo $length;
    }   

}else{
    $query = "SELECT s.Score, s.Date, u.Nickname FROM Score s LEFT JOIN Users u ON (s.Player_id = u.Id) WHERE s.GameName = '".$_POST['Game']."' ORDER BY s.Score DESC LIMIT 0, ".$_POST['Amount'].""; 

    if (!($result = $mysqli->query($query))){
        showerror($mysqli->errno,$mysqli->error);
        echo "oops";
    }else{

        $result = $mysqli->query($query);    

        $t = array();
        $result = $mysqli->query($query);    
        while($row = mysqli_fetch_assoc($result)){                       
            $t[] = $row;
        }
        echo json_encode($t);

    }
    
}
       

?> 