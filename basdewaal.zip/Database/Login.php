<?php
    include "DatabaseInlog.php";


    $Email = $_POST["Email"];
    $Password = $_POST["Password"];
    $Email = filter_var($Email, FILTER_SANITIZE_EMAIL);
    $Password = filter_var($Password, FILTER_SANITIZE_SPECIAL_CHARS);

    $query = "SELECT * FROM Users WHERE Email = '". $Email ."' and Password = '". $Password ."' LIMIT 1";
    if(!($result = $mysqli->query($query)))
        showerror($mysqli->errno,$mysqli->error);
    
    if($row = $result->fetch_assoc()){
        session_start();
        echo session_id();       
        $_SESSION['Speler'] = $row['Id'];  
        $_SESSION['Game'] = $_POST["Game"];        

        echo "/";
        echo $row['Nickname'];
    }else{
        echo"Wrong Password or Email.";
    }
    
?>