<?php
    include "DatabaseInlog.php";

  

if(isset($_GET['userName'])){
$userName = $_GET['userName'];

echo "ID" . " | " . "Username" . " | " . "Birthday" . " | " . "Password" . " | " . "Sex" . " | " . "Start at" . " | " . "<br>"; 

echo $queryUsers = "INSERT INTO Users (Id, Username, Birthday, Password, Sex, Started_at) 
                VALUES (NULL, '".$userName."', '2018-05-01', 'sada', 1, Now())";

if (!($result = $mysqli->query($queryUsers)))
showerror($mysqli->errno,$mysqli->error);


}


/*
function InsertUser(Id, Username, Birthday, Password, Sex, Started at){    
     $query.Users = "INSERT INTO Users (Id, Username, Birthday, Password, Sex, Started at) 
                    VALUES ('123', 'sad', '2018-05-01', 'sada', '1', '2018-05-07 00:10:00')";

}*/




?>