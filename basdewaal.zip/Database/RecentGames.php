<?php
    include "DatabaseInlog.php";


if (isset($_GET['PHPSESSID'])){
    $sid = htmlspecialchars($_GET['PHPSESSID']);
    session_id($sid);   
    session_start(); 
}

$query = "SELECT s.Score, s.Date, u.Nickname FROM Score s LEFT JOIN Users u ON (s.player_id = u.id) WHERE s.GameName = '".$_POST['Game']."' AND s.Date BETWEEN '".$_POST['dateFirst']."' AND '".$_POST['dateSecond']."' 
AND s.Player_id = ".$_SESSION['Speler']." ORDER BY s.Score DESC LIMIT 0, ".$_POST['Amount'].""; 

$legth = 0;
$result = $mysqli->query($query);    
if (!($result = $mysqli->query($query)))
    showerror($mysqli->errno,$mysqli->error);
else{
    $t = array();
    $result = $mysqli->query($query);    
    while($row = mysqli_fetch_assoc($result)){                       
        $t[] = $row;
    }
    echo json_encode($t);
}

                


?>