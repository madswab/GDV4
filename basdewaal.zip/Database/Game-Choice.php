<?php
    include "DatabaseInlog.php";


if (isset($_GET['PHPSESSID'])){
    $sid = htmlspecialchars($_GET['PHPSESSID']);
    session_id($sid);   
    session_start(); 
}

if (isset($_SESSION['Game'])){
    
    $query = "SELECT * FROM Games";
    if (!($result = $mysqli->query($query)))
        showerror($mysqli->errno,$mysqli->error);

    $row = $result->fetch_assoc();

    echo $queryScore = "INSERT INTO Score    (Id, Score, GameName, Date, Player_id) 
                        VALUES (NULL, ".$_POST['Score'].", '".$_SESSION['Game']."', Now(), ".$_SESSION['Speler'].")";

    if (!($result = $mysqli->query($queryScore)))
        showerror($mysqli->errno,$mysqli->error);
}

?> 