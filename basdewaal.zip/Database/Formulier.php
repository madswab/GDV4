<?php
    include "DatabaseInlog.php";


$UnityGetSet = $_POST["GetSet"];

$Email = NULL;
$Password = NULL;
$Birthday = NULL;
$Sex = NULL;
$Nickname = NULL;


switch($UnityGetSet){
        
    case "Get":
        //echo "Get";
            if (isset($_GET['PHPSESSID'])){
                $sid = htmlspecialchars($_GET['PHPSESSID']);
                session_id($sid);   
                session_start();        
            }

            $query = "SELECT * FROM Users WHERE Id = ".$_SESSION['Speler']." LIMIT 1";


            $result = $mysqli->query($query);    
            if (!($result = $mysqli->query($query)))
            showerror($mysqli->errno,$mysqli->error);
            else{
                $t = array();
                $result = $mysqli->query($query);    
                while($row = mysqli_fetch_assoc($result)){                       
                    $t[] = $row;
                }

            echo json_encode($t);

            }
        break;
    case "Set":
        //echo "Set";        
            if (isset($_POST["ID"])){
                $sid = htmlspecialchars($_POST["ID"]);
                session_id($sid);   
                
                echo session_save_path();
                session_start();        
                    
                $queryUsers = "UPDATE Users SET Email = '".$_POST["Email"]."', Password = '".$_POST["Password"]."', Birthday = '".$_POST["Birthday"]."', Sex = ".$_POST["Sex"].", Nickname = '".$_POST["Nickname"]."' WHERE (Id = ".$_SESSION['Speler'].") ";

                if (!($result = $mysqli->query($queryUsers)))
                    showerror($mysqli->errno,$mysqli->error);
                echo "Success";

            }else{
                $queryUsers = "INSERT INTO Users (Id, Email, Password, Birthday, Sex, Started_at, Nickname) 
                            VALUES (NULL, '".$_POST["Email"]."', '".$_POST["Password"]."', '".$_POST["Birthday"]."', ".$_POST["Sex"].", Now(), '".$_POST["Nickname"]."')";

                if (!($result = $mysqli->query($queryUsers)))
                    showerror($mysqli->errno,$mysqli->error);
                echo "Success";
            }
        break;
        
}

?>
