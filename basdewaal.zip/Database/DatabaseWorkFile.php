<?php
    include "DatabaseInlog.php";


//echo "<table style='border: solid 1px black;'>";
//echo "<tr><th>Id</th><th>|</th><th>Username</th><th>|</th><th>Birthday</th><th>|</th><th>Password</th><th>|</th><th>Sex</th></tr>";


$query = "SELECT * FROM `Users`";

if (!($result = $mysqli->query($query)))
showerror($mysqli->errno,$mysqli->error);


echo "ID" . " | " . "Username" . " | " . "Birthday" . " | " . "Password" . " | " . "Sex" . " | " . "Start at" . " | " . "<br>"; 


$row = $result->fetch_assoc();

do {
echo ($row["Id"] . " | " . $row["Username"] . " | " . $row["Password"] . " | " . $row["Birthday"] . " | " . $row["Sex"] . " | " . "<br>");
} while ($row = $result->fetch_assoc());

echo "<br>";    
echo "dsadsa";

/*$query = "SELECT Id, MAX(Score) as highscore FROM `Score` WHERE GameName = 'Game1'";

if (!($result = $mysqli->query($query)))
showerror($mysqli->errno,$mysqli->error);

$row = $result->fetch_assoc();

echo json_encode($row);
*/
?>

