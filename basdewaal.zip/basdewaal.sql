-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 22 jun 2018 om 12:43
-- Serverversie: 5.7.17
-- PHP-versie: 5.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `basdewaal`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Games`
--

CREATE TABLE IF NOT EXISTS `Games` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `GameName` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Gegevens worden uitgevoerd voor tabel `Games`
--

INSERT INTO `Games` (`Id`, `GameName`) VALUES
(1, 'test'),
(2, 'test2'),
(3, 'MulitplayerBreakout');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Score`
--

CREATE TABLE IF NOT EXISTS `Score` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Score` int(11) NOT NULL,
  `GameName` text NOT NULL,
  `Date` datetime NOT NULL,
  `Player_id` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=289 ;

--
-- Gegevens worden uitgevoerd voor tabel `Score`
--

INSERT INTO `Score` (`Id`, `Score`, `GameName`, `Date`, `Player_id`) VALUES
(268, 80, 'MulitplayerBreakout', '2018-06-14 23:08:43', 1),
(269, 80, 'MulitplayerBreakout', '2018-06-14 23:17:00', 245),
(270, 80, 'MulitplayerBreakout', '2018-06-14 23:20:54', 1),
(271, 0, 'MulitplayerBreakout', '2018-06-15 07:43:04', 245),
(272, 0, 'MulitplayerBreakout', '2018-06-15 07:44:09', 245),
(273, 10, 'MulitplayerBreakout', '2018-06-15 07:46:41', 245),
(274, 0, 'MulitplayerBreakout', '2018-06-15 07:46:42', 1),
(275, 0, 'MulitplayerBreakout', '2018-06-15 08:02:43', 1),
(276, 20, 'MulitplayerBreakout', '2018-06-15 08:23:47', 245),
(277, 40, 'MulitplayerBreakout', '2018-06-15 08:23:48', 1),
(278, 80, 'MulitplayerBreakout', '2018-06-15 08:29:29', 245),
(279, 80, 'MulitplayerBreakout', '2018-06-15 08:34:44', 1),
(280, 40, 'MulitplayerBreakout', '2018-06-15 08:34:45', 245),
(281, 10, 'MulitplayerBreakout', '2018-06-15 08:37:06', 245),
(282, 90, 'MulitplayerBreakout', '2018-06-15 08:37:07', 1),
(283, 240, 'MulitplayerBreakout', '2018-06-15 10:14:12', 1),
(284, 100, 'MulitplayerBreakout', '2018-06-15 10:14:13', 245),
(285, 20, 'MulitplayerBreakout', '2018-06-15 10:28:20', 1),
(286, 20, 'MulitplayerBreakout', '2018-06-15 10:28:21', 1),
(287, 20, 'MulitplayerBreakout', '2018-06-15 10:28:22', 1),
(288, 80, 'MulitplayerBreakout', '2018-06-15 10:28:24', 245);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(50) NOT NULL,
  `Birthday` date NOT NULL,
  `Password` text NOT NULL,
  `Sex` tinyint(1) DEFAULT NULL,
  `Started_at` datetime NOT NULL,
  `Nickname` text NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=259 ;

--
-- Gegevens worden uitgevoerd voor tabel `Users`
--

INSERT INTO `Users` (`Id`, `Email`, `Birthday`, `Password`, `Sex`, `Started_at`, `Nickname`) VALUES
(1, 'test@test.com', '2018-05-14', '1', 0, '2018-05-14 00:00:00', 'UserTest1'),
(240, 'test1@test.com', '2018-05-14', '2', 1, '2018-06-03 21:02:08', 'UserTest2'),
(245, 't@t.com', '1911-02-02', '2', 0, '2018-06-08 23:17:18', 'TestCreateFormulier'),
(248, 'b@b.com', '1910-01-01', '12', 0, '2018-06-13 13:17:20', 'fdsfdsgd'),
(249, 'm@m.com', '1910-01-01', '123', 0, '2018-06-13 13:59:54', 'dsadsadas'),
(255, 't@t.comM', '1911-02-02', '3', 0, '2018-06-15 10:27:27', 'TestCreateFormulier'),
(257, 'test@t.com', '1911-02-02', '123', 0, '2018-06-15 10:29:50', 'TestCreateFormulier'),
(258, 'qwe@wer.com', '1910-01-01', '098', 0, '2018-06-15 10:30:35', 'trerer');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
